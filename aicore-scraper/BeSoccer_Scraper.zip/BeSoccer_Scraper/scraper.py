from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
import time
from bs4 import BeautifulSoup as bs
import requests
from tqdm import tqdm
import pandas as pd
import os
import pathlib
class Scraper:
    def __init__(self, league:str, url:str='https://www.besoccer.com/competition', year: int=2022) -> None:
        pathlib.Path(f'Data/Results/{league}').mkdir(parents=True, exist_ok=True) 
        pathlib.Path(f'Data/To_Predict/{league}').mkdir(parents=True, exist_ok=True) 
        self.league = league
        self.url = url
        self.year = year
        r = requests.get(f"{self.url}/scores/{self.league}/{self.year}")
        time.sleep(1)
        soup = bs(r.content, 'html.parser')
        matchday_str = soup.find('div', {'class': 'panel-title'}).text
        self.current_matchday = [int(s) for s in matchday_str.split() if s.isdigit()][0]
        self.current_matchday_flag = self.check_current_matchday()

    def get_previous_matches(self):
        results = {'Home_Team': [], 'Away_Team': [], 'Result': [], 'Link': [], 'Season': [], 'Round': [], 'League': []}
        for matchday in tqdm(range(1, self.current_matchday)):
            r = requests.get(f"{self.url}/scores/{self.league}/{self.year}/round{matchday}")
            time.sleep(2)
            soup = bs(r.content, 'html.parser')
            matches_box = soup.find('div', {'class': 'panel-body p0 match-list-new'})
            matches = matches_box.find_all('a', {'class': 'match-link'})
            for match in matches:
                home_team = match.find('div', {'class': 'team-info ta-r'}).find('div', {'class': 'name'}).text.strip()
                away_team = match.find(lambda tag: tag.name == 'div' and 
                                   tag.get('class') == ['team-info']).find('div', {'class': 'name'}).text.strip()
                header = match.find('div', {'class': 'info-head'})
                if header.find('span', {'class': 'tag end'}):
                    home_score = match.find('div', {'class': 'marker'}).find('span', {'class': 'r1'}).text.strip()
                    away_score = match.find('div', {'class': 'marker'}).find('span', {'class': 'r2'}).text.strip()
                    results['Result'].append(f'{home_score}-{away_score}')
                else:
                    results['Result'].append('Postponed')
                results['Home_Team'].append(home_team)
                results['Away_Team'].append(away_team)
                results['Link'].append(match.get('href'))
                results['Season'].append(self.year)
                results['Round'].append(matchday)
                results['League'].append(self.league)
        df = pd.DataFrame(results)
        df.to_csv(f'Data/Results/{self.league}/Results_{self.year}_{self.league}.csv')
        return df
    
    def get_next_match(self):
        results = {'Home_Team': [], 'Away_Team': [], 'Link': [], 'Season': [], 'Round': [], 'League': []}
        if self.current_matchday_flag:
            r = requests.get(f"{self.url}/scores/{self.league}/{self.year}/round{self.current_matchday}")
        else:
            r = requests.get(f"{self.url}/scores/{self.league}/{self.year}/round{self.current_matchday + 1}")
        
        time.sleep(2)
        soup = bs(r.content, 'html.parser')
        matches_box = soup.find('div', {'class': 'panel-body p0 match-list-new'})
        matches = matches_box.find_all('a', {'class': 'match-link'})
        for match in matches:
            header = match.find('div', {'class': 'info-head'})
            if header.find('span', {'class': 'tag end'}): # Include only matches that have not started yet
                continue
            else:
                home_team = match.find('div', {'class': 'team-info ta-r'}).find('div', {'class': 'name'}).text.strip()
                away_team = match.find('div', {'class': 'team-info'}).find('div', {'class': 'name'}).text.strip()
                results['Home_Team'].append(home_team)
                results['Away_Team'].append(away_team)
                results['Link'].append(match.get('href'))
                results['Season'].append(self.year)
                results['Round'].append(self.current_matchday + 1)
                results['League'].append(self.league)
        df = pd.DataFrame(results)
        df.to_csv(f'Data/To_Predict/{self.league}/Results_{self.year}_{self.league}.csv')
        return df
    
    def check_current_matchday(self):
        '''
        Checks if in the current matchday there are any matches to predict.
        '''
        r = requests.get(f"{self.url}/scores/{self.league}/{self.year}/round{self.current_matchday}")
        time.sleep(2)
        soup = bs(r.content, 'html.parser')
        matches_box = soup.find('div', {'class': 'panel-body p0 match-list-new'})
        matches = matches_box.find_all('a', {'class': 'match-link'})
        for match in matches:
            header = match.find('div', {'class': 'info-head'})
            if header.find('span', {'class': 'tag end'}):
                return True
        return False


if __name__ == '__main__':
    leagues = ['primera_division', 'segunda_division', # Spain
               'serie_a', 'serie_b',  # Italy
               'bundesliga', '2_liga', # Germany
               'ligue_1', 'ligue_2', # France
               'premier_league', 'championship', # England
               'eredivisie', 'eerste_divisie', # Netherlands
               'primeira_liga', 'segunda_liga', # Portugal
               ]
    league_dict = {league: {'Scraper': None, 'Results': None, 'To_Predict': None} for league in leagues}
    for league in leagues:
        print(f'Getting information about {league}')
        league_dict[league]['Scraper'] = Scraper(league)
        league_dict[league]['Results'] = league_dict[league]['Scraper'].get_previous_matches()
        league_dict[league]['To_Predict'] = league_dict[league]['Scraper'].get_next_match()
        
